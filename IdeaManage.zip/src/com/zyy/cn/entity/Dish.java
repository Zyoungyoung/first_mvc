package com.zyy.cn.entity;

public class Dish {
    private int dishId;
    private String dishesName;
    private String dishesDiscript;
    private String dishesImg;
    private String dishesTxt;
    private int recommend;
    private float dishesPrice;

    public int getDishId() { return dishId; }

    public void setDishId(int dishId) { this.dishId = dishId; }

    public String getDishesName() { return dishesName; }

    public void setDishesName(String dishesName) { this.dishesName = dishesName; }

    public String getDishesDiscript() { return dishesDiscript; }

    public void setDishesDiscript(String dishesDiscript) { this.dishesDiscript = dishesDiscript; }

    public String getDishesImg() { return dishesImg; }

    public void setDishesImg(String dishesImg) { this.dishesImg = dishesImg; }

    public String getDishesTxt() { return dishesTxt; }

    public void setDishesTxt(String dishesTxt) { this.dishesTxt = dishesTxt; }

    public int getRecommend() { return recommend; }

    public void setRecommend(int recommend) { this.recommend = recommend; }

    public float getDishesPrice() { return dishesPrice; }

    public void setDishesPrice(float dishesPrice) { this.dishesPrice = dishesPrice; }

    public Dish(){}

    public Dish(int dishId,String dishesName,String dishesDiscript,String dishesImg,String dishesTxt,int recommend,float dishesPrice){
        this.dishId=dishId;
        this.dishesName=dishesName;
        this.dishesDiscript=dishesDiscript;
        this.dishesImg=dishesImg;
        this.dishesTxt=dishesTxt;
        this.recommend=recommend;
        this.dishesPrice=dishesPrice;
    }





    @Override
    public String toString() {
        return "Dish{" +
                "dishId=" + dishId +
                ", dishesName='" + dishesName + '\'' +
                ", dishesDiscript='" + dishesDiscript + '\'' +
                ", dishesImg='" + dishesImg + '\'' +
                ", dishesTxt='" + dishesTxt + '\'' +
                ", recommend=" + recommend +
                ", dishesPrice=" + dishesPrice +
                '}';
    }
}
