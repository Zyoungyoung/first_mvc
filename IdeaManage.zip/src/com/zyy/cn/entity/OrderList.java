package com.zyy.cn.entity;

public class OrderList {
    private int odld;
    private int orderReference;
    private String dishes;
    private int num;

    public OrderList(int odld, int orderReference, String dishes, int num) {
        this.odld = odld;
        this.orderReference = orderReference;
        this.dishes = dishes;
        this.num = num;
    }

    public int getOdld() { return odld; }

    public void setOdld(int odld) { this.odld = odld; }

    public int getOrderReference() { return orderReference; }

    public void setOrderReference(int orderReference) { this.orderReference = orderReference; }


    public int getNum() { return num; }

    public void setNum(int num) { this.num = num; }
    public OrderList(){};

    public String getDishes() { return dishes;
    }

    public void setDishes(String dishes) { this.dishes = dishes;
    }

    @Override
    public String toString() {
        return "OrderList{" +
                "odld=" + odld +
                ", orderReference=" + orderReference +
                ", dishes='" + dishes + '\'' +
                ", num=" + num +
                '}';
    }
}
