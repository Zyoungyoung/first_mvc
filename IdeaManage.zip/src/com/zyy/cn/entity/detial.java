package com.zyy.cn.entity;

import com.zyy.cn.Util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class detial {
    private String Message;

    private int place;
    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public detial(){};

    public detial(String Message,int place){
        this.Message=Message;
        this.place=place;
    }
    public detial(String Message){
        this.Message=Message;
    }



//    public int insertDetial(String detial) {
//        Connection connection = DBUtil.getConnection();
//        String sql = "insert into message(Message) " + "values(?);";
//        PreparedStatement pstm = null;
//        int result = 0;
//
//        try {
//            pstm = connection.prepareStatement(sql);
//            pstm.setString(1,detial);
//
//            result = pstm.executeUpdate();
//
//        } catch (SQLException e) {
//            System.out.println("已存在，请重新插入");
//            //e.printStackTrace();
//        } finally {
//            DBUtil.close(pstm, null, connection);
//        }
//        return result;
//    }

    public int getPlace() { return place; }

    public void setPlace(int place) { this.place = place; }

    @Override
    public String toString() {
        return "detial{" +
                "Message='" + Message + '\'' +
                ", place=" + place +
                '}';
    }
}
