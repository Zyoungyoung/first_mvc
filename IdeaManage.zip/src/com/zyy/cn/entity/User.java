package com.zyy.cn.entity;

import com.zyy.cn.Util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class User {
    private int userId;
    private String userAccount;
    private String userPass;
    private int userrole;
    private int locked;
    private String faceimg;
    private String note;

    public int getUserld() { return userId;
    }

    public void setUserld(int userld) { this.userId = userld;
    }

    public String getUserAccount() { return userAccount;
    }

    public void setUserAccount(String userAccount) { this.userAccount = userAccount;
    }

    public String getUserPass() { return userPass;
    }

    public void setUserPass(String userPass) { this.userPass = userPass;
    }

    public int getUserrole() { return userrole;
    }

    public void setUserrole(int userrole) { this.userrole = userrole;
    }

    public int getLocked() { return locked;
    }

    public void setLocked(int locked) { this.locked = locked;
    }

    public String getFaceimg() { return faceimg;
    }

    public void setFaceimg(String faceimg) { this.faceimg = faceimg;
    }

    public User(){};
    //无参构造方法
    public User(int userld,String userAccount,String userPass,int userrole,int locked,String faceimg){
            this.userAccount = userAccount;
            this.locked = locked;
            this.userPass=userPass;
            this.userId=userld;
            this.faceimg=faceimg;
            this.userrole=userrole;
    }
    public static void main(String[] args) {
        Connection ct =DBUtil.getConnection();
        String sql = "select * from userinfo";

        PreparedStatement pstm = null;
        ResultSet rs = null;

        List<User> users = new ArrayList<User>();

        try {

            pstm = ct.prepareStatement(sql);
            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
//                将用户信息添加到这个user中
                System.out.println("name"+rs.getString("userId"));
//                User user = new User();
//                user.setUserld(rs.getInt("userId"));
//                user.setUserAccount(rs.getString("userAccount"));
//                user.setUserPass(rs.getString("userPass"));
//                user.setUserrole(rs.getInt("role"));
//                user.setLocked(rs.getInt("locked"));
//                user.setFaceimg(rs.getString("faceimg"));
//                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, ct);
        }

    }

    @Override
    public String toString() {
        return "User{" +
                "userld=" + userId +
                ", userAccount='" + userAccount + '\'' +
                ", userPass='" + userPass + '\'' +
                ", userrole=" + userrole +
                ", locked=" + locked +
                ", faceimg='" + faceimg + '\'' +
                '}';
    }



    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
