package com.zyy.cn.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.Detail;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.zyy.cn.Util.DBUtil;
import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.User;
import com.zyy.cn.entity.detial;

@WebServlet("/home")

public class HelloServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection ct = DBUtil.getConnection();
        String sql = "select * from message";
        ResultSet rt = null;
        PreparedStatement pt= null;
//        String del = req.getParameter("delt");
//        System.out.println(del);
//        问题出现在DButil这个文件配置
        try {
            pt = ct.prepareStatement(sql);
            rt = pt.executeQuery();
            List<String> list = null;
            while (rt.next()) {
                list = new ArrayList<>();
                list.add(rt.getString("Message"));
//                list.add(rt.getString("place"));
            }
            req.setAttribute("list", list);
            req.setAttribute("loginError", "发布成功！");          // 设置错误属性
            req.getRequestDispatcher("cook/message.jsp").forward(req, resp);
        }catch (Exception e){
            e.printStackTrace();
        }



    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
