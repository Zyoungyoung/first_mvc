package com.zyy.cn.servlet;

import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet("/delete")
public class UserDelete extends HelloServlet{
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        int deleteId = Integer.valueOf(req.getParameter("deleteId")).intValue();
        UserDao userDao = new UserDao();
        if (deleteId!=0) {
            System.out.println(userDao.deleteUser(deleteId) > 0 ? "删除成功" : "删除失败");
            req.setAttribute("loginSuccess","修改成功");
            req.getRequestDispatcher("manager/queryUser.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
