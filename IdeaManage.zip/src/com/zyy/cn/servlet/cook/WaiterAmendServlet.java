package com.zyy.cn.servlet.cook;

import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/Waiter")
public class WaiterAmendServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {




//        根据用户id号来修改用户的姓名信息
        int userId =Integer.valueOf(req.getParameter("userId")).intValue();
        String userAccount = req.getParameter("userAccount");
        String userPass = req.getParameter("userPass");
        int role =Integer.valueOf(req.getParameter("role")).intValue();
        int locked =Integer.valueOf(req.getParameter("locked")).intValue();
        String faceimg = req.getParameter("faceimg");
        String note = new String( req.getParameter("note").getBytes("iso8859-1"), "utf-8");

        if(userId!=0){
            UserDao userup =new UserDao();
            User u1 =userup.selectUserById(userId,userAccount,userPass,role,locked,faceimg,note);
            if(u1 !=null){
                System.out.println(userup.updateUserByID(u1) > 0 ? "修改成功" : "修改失败");
                req.setAttribute("loginError", "修改成功！");          // 设置错误属性
                req.getRequestDispatcher("waiter/AmendWaiter.jsp").forward(req,resp);
            }else{
                resp.sendRedirect("cook/IDerror.jsp");
            }

        }


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
