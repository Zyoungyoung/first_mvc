package com.zyy.cn.servlet.cook;

import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;


@MultipartConfig
@WebServlet("/PicUpload")
public class PicUploadServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("上传接口");

        //设置将提交后的图片保存到服务端项目的指定位置（这里是获取到当前项目的img下的路径）
        String path = getServletContext().getRealPath("/img");
        //使用part接收服务端传来的图片
        Part part = req.getPart("image");
        //然后将图片写入到服务端指定的路径,这里设置存储到服务端图片的名称还是原来图片的名称
        String imagePath = "C:/";
        part.write(imagePath+part.getSubmittedFileName());


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
