package com.zyy.cn.servlet.cook;

import com.zyy.cn.dao.OrderListDao;
import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.OrderList;
import com.zyy.cn.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/cookDishes")

public class CookDishes extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");


        int orId = Integer.valueOf(req.getParameter("orId")).intValue();
        String dishName =req.getParameter("dishes");
        int num = Integer.valueOf(req.getParameter("number")).intValue();


        if( orId != 0 ){
            OrderListDao orderListDao = new OrderListDao();
          OrderList orderWaiter =  orderListDao.selectDishById(orId);


//            将数据传入session中
            HttpSession se = req.getSession();
            se.setAttribute("orderWaiter",orderWaiter);

            req.setAttribute("loginError", "开始烹饪"+dishName+" 份数："+num+"预计五分钟出菜");          // 设置错误属性
            req.getRequestDispatcher("cook/CookDishes.jsp").forward(req,resp);
        }else {
            resp.sendRedirect("cook/IDerror.jsp");
        }





    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
