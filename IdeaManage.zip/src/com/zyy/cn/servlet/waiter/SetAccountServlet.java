package com.zyy.cn.servlet.waiter;

import com.zyy.cn.dao.DishDao;
import com.zyy.cn.dao.OrderDao;
import com.zyy.cn.dao.OrderListDao;
import com.zyy.cn.entity.Dish;
import com.zyy.cn.entity.OrderList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@WebServlet("/Account")
public class SetAccountServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset = utf-8");


        OrderListDao orderListDao =new OrderListDao();
        int orId = Integer.valueOf(req.getParameter("odId")).intValue();
        int num =   Integer.valueOf(req.getParameter("num")).intValue();
        int tabId= Integer.valueOf(req.getParameter("tabId")).intValue();
        OrderList orderList =orderListDao.selectDishById(orId);
        String dishName = orderList.getDishes();

//        根据菜名找到他的价格
        DishDao dishDao = new DishDao();
        Dish dish =dishDao.selectDishPriceById(dishName);
//        获得菜品价格
        float price =dish.getDishesPrice() * num;
        req.setAttribute("loginError", tabId+"号桌结账成功，客人您需要支付的金额为："+price);


        Date date = new Date();

//      一、获取当前系统时间和日期并格式化输出:
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        System.out.println(dateTime);  // 2019-07-03 10:14:14
        int waiterId=17;
        OrderDao orderDao = new OrderDao();
        System.out.println(orderDao.insertOrder(orId+10,dateTime,dateTime,waiterId,num,tabId) >0 ?"添加成功":"添加失败");


        System.out.println(orderListDao.deleteUser(orId) >0 ?"结账成功":"结账失败");
        req.getRequestDispatcher("waiter/setAccount.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
