package com.zyy.cn.servlet;

import com.zyy.cn.dao.DishDao;
import com.zyy.cn.dao.OrderDao;
import com.zyy.cn.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/remove")
public class DishesDelete extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        int deleteId = Integer.valueOf(req.getParameter("dishId")).intValue();
//        OrderDao orderDao =new OrderDao();
//        orderDao.deleteUser(deleteId);
        DishDao dishDao = new DishDao();
        if(deleteId !=0){
        System.out.println(dishDao.deleteDishes(deleteId)>0 ?"删除成功" :"删除失败" );
        req.setAttribute("loginError", "修改成功！");          // 设置错误属性
        req.getRequestDispatcher("manager/queryDishes.jsp").forward(req,resp);
        }else {
            resp.sendRedirect("cook/IDerror.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
