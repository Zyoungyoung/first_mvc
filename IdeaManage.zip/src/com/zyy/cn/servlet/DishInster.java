package com.zyy.cn.servlet;

import com.zyy.cn.dao.DishDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/Insert")
public class DishInster extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        int dishesId =Integer.valueOf(req.getParameter("dishId")).intValue();
        String dishesName = new String( req.getParameter("dishesName").getBytes("iso8859-1"), "utf-8");
        String dishesDiscript = new String( req.getParameter("dishNew").getBytes("iso8859-1"), "utf-8");
        String dishesImg =req.getParameter("dishesImg");
        int recommend = Integer.valueOf(req.getParameter("recommend")).intValue();
        float dishesPrice = Float.valueOf(req.getParameter("dishesPrice")).floatValue();
        String dishesTxt = new String( req.getParameter("dishesTxt").getBytes("iso8859-1"), "utf-8");




        DishDao insertDao = new DishDao();
        if(dishesId!=0){
        System.out.println(insertDao.insertDish(dishesId,dishesName, dishesDiscript, dishesImg,recommend,dishesPrice,dishesTxt) >0 ?"插入成功" :"插入失败" );
            req.setAttribute("loginError", "插入成功！");          // 设置错误属性
        req.getRequestDispatcher("manager/insterDish.jsp").forward(req,resp);
        }else {
            resp.sendRedirect("cook/IDerror.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }



}
