package com.zyy.cn.servlet.orderServlet;

import com.zyy.cn.dao.DishDao;
import com.zyy.cn.dao.OrderDao;
import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.Order;
import com.zyy.cn.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
@WebServlet("/Order")
public class OrderServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        OrderDao orderDao = new OrderDao();
        List<Order> orders = orderDao.selectOrder();
//        int id = 9;
//        orderDao.deleteDish(id);

        req.setAttribute("orders",orders);
        req.getRequestDispatcher("manager/queryOrder.jsp").forward(req,resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
