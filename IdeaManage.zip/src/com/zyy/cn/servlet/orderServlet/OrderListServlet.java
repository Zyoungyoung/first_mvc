package com.zyy.cn.servlet.orderServlet;

import com.zyy.cn.dao.OrderDao;
import com.zyy.cn.dao.OrderListDao;
import com.zyy.cn.dao.detialDao;
import com.zyy.cn.entity.Order;
import com.zyy.cn.entity.OrderList;
import com.zyy.cn.entity.detial;
import com.zyy.cn.servlet.HelloServlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet("/OrderList")
public class OrderListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        resp.setContentType("text/html;charset=utf-8");
        detialDao DetialDao = new detialDao();
        List<detial> detials = DetialDao.selectDetial();
//        System.out.println(detials.toString());
//        发布公告
        String detial = req.getParameter("message");
//        String detial = new String(req.getParameter("message").getBytes("iso8859-1"), "utf-8");
        if(detial!=null) {
            System.out.println(DetialDao.insertDetial(detial) > 0 ? "发布成功" : "发布失败");
        }
        req.setAttribute("details", detials);
       

        //这是传输顾客点餐列表
        OrderListDao orderListDao = new OrderListDao();
        List<OrderList> orders = orderListDao.selectOrderList();
        req.setAttribute("orders",orders);
        req.getRequestDispatcher("cook/mianpage.jsp").forward(req,resp);





    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
