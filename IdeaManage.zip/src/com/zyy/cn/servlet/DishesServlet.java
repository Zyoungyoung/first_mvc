package com.zyy.cn.servlet;

import com.zyy.cn.dao.DishDao;
import com.zyy.cn.dao.UserDao;
import com.zyy.cn.entity.Dish;
import com.zyy.cn.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet("/dishes")
public class DishesServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //        传输一个对象过去
        DishDao dishDao = new DishDao();
        List<Dish> dishes = dishDao.selectDish();
        req.setAttribute("dishes",dishes);
        req.getRequestDispatcher("manager/queryDishes.jsp").forward(req,resp);

        int dishesId =Integer.valueOf(req.getParameter("dishId")).intValue();
        String dishesName = new String( req.getParameter("dishesName").getBytes("iso8859-1"), "utf-8");
        String dishesDiscript = new String( req.getParameter("dishNew").getBytes("iso8859-1"), "utf-8");
        String dishesImg =req.getParameter("dishesImg");
        int recommend = Integer.valueOf(req.getParameter("recommend")).intValue();
        float dishesPrice = Float.valueOf(req.getParameter("dishesPrice")).floatValue();
        String dishesTxt = new String( req.getParameter("dishesTxt").getBytes("iso8859-1"), "utf-8");

        if(dishesId!=0){
            DishDao dishup =new DishDao();
            Dish d1 =dishup.selectDishById(dishesId,dishesName,dishesDiscript,dishesImg,recommend,dishesPrice,dishesTxt);
            System.out.println(dishup.updateDishByID(d1) > 0 ? "修改成功" : "修改失败");
        }


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
