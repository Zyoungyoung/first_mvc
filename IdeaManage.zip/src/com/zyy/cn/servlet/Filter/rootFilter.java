package com.zyy.cn.servlet.Filter;

//import com.hohong.pojo.User;
import com.zyy.cn.Util.Constant;


import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//如果用户未登录则不能访问登录以外的页面
public class rootFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");


        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        //获取登录用户信息


        //未登录跳转到登录页面
        if(req.getSession().getAttribute(Constant.USER_SESSION) == null){
            resp.sendRedirect("error.jsp");
        }

        System.out.println("过滤器执行前");
        //放行
        chain.doFilter(request,response);
        System.out.println("过滤器执行后");
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("过滤器初始化");
    }

    @Override
    public void destroy() {

    }
}


