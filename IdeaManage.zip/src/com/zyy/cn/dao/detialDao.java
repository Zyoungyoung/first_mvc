package com.zyy.cn.dao;

import com.zyy.cn.Util.DBUtil;
import com.zyy.cn.entity.Order;
import com.zyy.cn.entity.detial;

import javax.xml.soap.Detail;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class detialDao {
    public List<detial> selectDetial() {

        Connection connection = DBUtil.getConnection();
        String sql = "select * from message";

        PreparedStatement pstm = null;
        ResultSet rs = null;

        List<detial> users = new ArrayList<detial>();

        try {

            pstm = connection.prepareStatement(sql);
            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
//                将用户信息添加到这个user中
//                System.out.println("name"+rs.getString("userld"));
                detial Detial = new detial();
                Detial.setMessage(rs.getString("message"));

//                Detial.setPlace(rs.getInt("place"));


                users.add(Detial);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return users;
    }

//插入信息
    public int insertDetial(String detial) {
        Connection connection = DBUtil.getConnection();
        String sql = "insert into message(Message) " + "values(?);";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setString(1,detial);

            result = pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println("已存在，请重新插入");
            //e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }

}
