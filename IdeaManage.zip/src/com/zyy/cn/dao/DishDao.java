package com.zyy.cn.dao;

import com.zyy.cn.Util.DBUtil;
import com.zyy.cn.entity.Dish;
import com.zyy.cn.entity.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DishDao {

        public List<Dish> selectDish() {

            Connection connection = DBUtil.getConnection();
            String sql = "select * from dishesinfo";

            PreparedStatement pstm = null;
            ResultSet rs = null;

            List<Dish> dishes = new ArrayList<Dish>();

            try {

                pstm = connection.prepareStatement(sql);
                rs = pstm.executeQuery();
                // 遍历结果集
                while (rs.next()) {
//                将用户信息添加到这个user中
//                System.out.println("name"+rs.getString("userld"));
                    Dish dish = new Dish();
                    dish.setDishId(rs.getInt("dishesId"));
                    dish.setDishesName(rs.getString("dishesName"));
                    dish.setDishesDiscript(rs.getString("dishesDiscript"));
                    dish.setDishesImg(rs.getString("dishesImg"));
                    dish.setDishesTxt(rs.getString("dishesTxt"));
                    dish.setRecommend(rs.getInt("recommend"));
                    dish.setDishesPrice(rs.getFloat("dishesPrice"));
                    dishes.add(dish);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBUtil.close(pstm, rs, connection);
            }
            return dishes;
        }


        //根据菜品id获取菜品信息
        public Dish selectDishById(int dishesId, String dishesName, String dishesDiscript, String dishesImg,int recommend,float dishesPrice, String dishesTxt) {
            Connection connection = DBUtil.getConnection();
            String sql = "select * from dishesinfo where dishesId = ? ";
            Dish dish = null;
            PreparedStatement pstm = null;
            ResultSet rs = null;

            try {
                pstm = connection.prepareStatement(sql);
                pstm.setInt(1, dishesId);

                rs = pstm.executeQuery();
                // 遍历结果集
                while (rs.next()) {
                    dish = new Dish();
                    dish.setDishId(rs.getInt("dishesId"));
                    dish.setDishesName(dishesName);
                    dish.setDishesDiscript(dishesDiscript);
                    dish.setDishesImg(dishesImg);
                    dish.setDishesTxt(dishesTxt);
                    dish.setRecommend(recommend);
                    dish.setDishesPrice(dishesPrice);

                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBUtil.close(pstm, rs, connection);
            }
            return dish;
        }

        //修改菜品信息功能
        public int updateDishByID(Dish newDish) {
            Connection connection = DBUtil.getConnection();
            String sql = "update dishesinfo set dishesName = ?, dishesDiscript=?, dishesImg=?, dishesTxt=?, recommend=? ,dishesPrice= ? where dishesId = ?";
            PreparedStatement pstm = null;
            ResultSet rs = null;
            int result = 0;

            try {
                pstm = connection.prepareStatement(sql);
                pstm.setString(1, newDish.getDishesName());
                pstm.setString(2, newDish.getDishesDiscript());
                pstm.setString(3, newDish.getDishesImg());
                pstm.setString(4, newDish.getDishesTxt());
                pstm.setInt(5, newDish.getRecommend());
                pstm.setFloat(6, newDish.getDishesPrice());
                pstm.setInt(7, newDish.getDishId());

                result = pstm.executeUpdate();


            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBUtil.close(pstm, rs, connection);
            }
            return result;
        }
    public int deleteDishes(int dishesId) {
        Connection connection = DBUtil.getConnection();
        String sql = "delete from dishesinfo where dishesId = ?";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, dishesId);
            result = pstm.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }

    public int insertDish(int dishesId, String dishesName, String dishesDiscript, String dishesImg,int recommend,float dishesPrice, String dishesTxt) {
        Connection connection = DBUtil.getConnection();
        String sql = "insert into dishesinfo(dishesId,dishesName,dishesDiscript,dishesImg,dishesTxt,recommend,dishesPrice) " + "values(?,?,?,?,?,?,?);";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1,dishesId);
            pstm.setString(2, dishesName);
            pstm.setString(3,dishesDiscript);
            pstm.setString(4, dishesImg);
            pstm.setString(5, dishesTxt);
            pstm.setInt(6, recommend);
            pstm.setFloat(7,dishesPrice);


            result = pstm.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }

//根据菜品名称获取菜品价格
    public Dish selectDishPriceById( String dishesName) {
        Connection connection = DBUtil.getConnection();
        String sql = "select * from dishesinfo where dishesName = ? ";
        Dish dish = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setString(1, dishesName);

            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
                dish = new Dish();
                dish.setDishId(rs.getInt("dishesId"));
                dish.setDishesName(dishesName);
                dish.setDishesDiscript(rs.getString("dishesDiscript"));
                dish.setDishesImg(rs.getString("dishesImg"));
                dish.setDishesTxt(rs.getString("dishesTxt"));
                dish.setRecommend(rs.getInt("recommend"));
                dish.setDishesPrice(rs.getFloat("dishesPrice"));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return dish;
    }

}

