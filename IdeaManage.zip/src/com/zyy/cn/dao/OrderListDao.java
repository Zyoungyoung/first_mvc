package com.zyy.cn.dao;

import com.zyy.cn.Util.DBUtil;
import com.zyy.cn.entity.Dish;
import com.zyy.cn.entity.OrderList;
import com.zyy.cn.entity.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderListDao {
    public List<OrderList> selectOrderList() {

        Connection connection = DBUtil.getConnection();
        String sql = "select * from orderdishes";

        PreparedStatement pstm = null;
        ResultSet rs = null;

        List<OrderList> orderLists = new ArrayList<OrderList>();

        try {

            pstm = connection.prepareStatement(sql);
            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
                OrderList orderList = new OrderList();
                orderList.setDishes(rs.getString("dishes"));
                orderList.setNum(rs.getInt("num"));
                orderList.setOdld(rs.getInt("odId"));
                orderList.setOrderReference(rs.getInt("orderReference"));
                orderLists.add(orderList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return orderLists;
    }

    //   根据桌号ID删除用户信息
    public int deleteUser(int odId) {
        Connection connection = DBUtil.getConnection();
        String sql = "delete from orderdishes where odId = ?";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, odId);
            result = pstm.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }
//根据用户Id获取用户
    public OrderList selectDishById(int odId) {
        Connection connection = DBUtil.getConnection();
        String sql = "select * from orderdishes where odId = ? ";
        OrderList orderList = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, odId);

            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
                orderList = new OrderList();
                orderList.setOdld(rs.getInt("odId"));
                orderList.setOrderReference(rs.getInt("orderReference"));
                orderList.setDishes(rs.getString("dishes"));
                orderList.setNum(rs.getInt("num"));


            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return orderList;
    }
}
