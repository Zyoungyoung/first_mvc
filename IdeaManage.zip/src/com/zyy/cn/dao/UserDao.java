package com.zyy.cn.dao;
import com.zyy.cn.entity.User;
import com.zyy.cn.Util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    public  List<User> selectUser() {

        Connection connection = DBUtil.getConnection();
        String sql = "select * from userinfo";

        PreparedStatement pstm = null;
        ResultSet rs = null;

        List<User> users = new ArrayList<User>();

        try {

            pstm = connection.prepareStatement(sql);
            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
//                将用户信息添加到这个user中
//                System.out.println("name"+rs.getString("userld"));
                User user = new User();
                user.setUserld(rs.getInt("userId"));
                user.setUserAccount(rs.getString("userAccount"));
                user.setUserPass(rs.getString("userPass"));
                user.setUserrole(rs.getInt("role"));
                user.setLocked(rs.getInt("locked"));
                user.setFaceimg(rs.getString("faceimg"));
                user.setNote(rs.getString("note"));
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return users;
    }

//根据用户id获取用户
public User selectUserById(int userId,String userAccount,String userPass,int role,int locked,String faceimg,String note) {
    Connection connection = DBUtil.getConnection();
    String sql = "select * from userinfo where userId = ? ";
    User user = null;
    PreparedStatement pstm = null;
    ResultSet rs = null;

    try {
        pstm = connection.prepareStatement(sql);
        pstm.setInt(1, userId);

        rs = pstm.executeQuery();
        // 遍历结果集
        while (rs.next()) {
            user = new User();
            user.setUserld(rs.getInt("userId"));
            user.setUserAccount(userAccount);
            user.setUserPass(userPass);
            user.setUserrole(role);
            user.setLocked(locked);
            user.setFaceimg(faceimg);
            user.setNote(note);

        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        DBUtil.close(pstm, rs, connection);
    }
    return user;
}

//修改用户信息功能
    public int updateUserByID(User newUser) {
        Connection connection = DBUtil.getConnection();
        String sql = "update userinfo set userAccount = ?, userPass=?, role=?, locked=?, faceimg=? ,note= ? where userId = ?";
        PreparedStatement pstm = null;
        ResultSet rs = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setString(1, newUser.getUserAccount());
            pstm.setString(2, newUser.getUserPass());
            pstm.setInt(3, newUser.getUserrole());
            pstm.setInt(4, newUser.getLocked());
            pstm.setString(5, newUser.getFaceimg());
            pstm.setString(6,newUser.getNote());
            pstm.setInt(7,newUser.getUserld());

            result = pstm.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return result;
    }
//   根据用户ID删除用户信息
    public int deleteUser(int userId) {
        Connection connection = DBUtil.getConnection();
        String sql = "delete from userinfo where userId = ?";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, userId);
            result = pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println("学号不存在，请重新输入");
            //e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }
//增加用户
    public int insertUser(User newUser) {
        Connection connection = DBUtil.getConnection();
        String sql = "insert into userinfo(userId,userAccount,userPass,`role`,locked,faceimg,note) " + "values(?,?,?,?,?,?,?);";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, newUser.getUserld());
            pstm.setString(2, newUser.getUserAccount());
            pstm.setString(3, newUser.getUserPass());
            pstm.setInt(4, newUser.getUserrole());
            pstm.setInt(5, newUser.getLocked());
            pstm.setString(6, newUser.getFaceimg());
            pstm.setString(7,newUser.getNote());


            result = pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println("学号已存在，请重新插入");
            //e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }

    public static void main(String[] args) {
        UserDao userDao = new UserDao();
        List<User> users = userDao.selectUser();
        System.out.println(users.toString());
    }


}
