package com.zyy.cn.dao;

import com.zyy.cn.Util.DBUtil;
import com.zyy.cn.entity.Dish;
import com.zyy.cn.entity.Order;
import com.zyy.cn.entity.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//查询订单
public class OrderDao {
//    查询往期订单
    public List<Order> selectOrder() {

        Connection connection = DBUtil.getConnection();
        String sql = "select * from orderinfo";

        PreparedStatement pstm = null;
        ResultSet rs = null;

        List<Order> users = new ArrayList<Order>();

        try {

            pstm = connection.prepareStatement(sql);
            rs = pstm.executeQuery();
            // 遍历结果集
            while (rs.next()) {
//                将用户信息添加到这个user中
//                System.out.println("name"+rs.getString("userld"));
                Order order = new Order();
                order.setOrderId(rs.getInt("orderId"));
                order.setOrderBeginDate(rs.getString("orderBeginDate"));
                order.setOrderEndDate(rs.getString("orderEndDate"));
                order.setWaiterId(rs.getInt("waiterId"));
                order.setOrderState(rs.getInt("orderState"));
                order.setTableId(rs.getInt("tableId"));
                users.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, rs, connection);
        }
        return users;
    }



    //取消订单功能
    public int deleteDish(int orderId) {
        Connection connection = DBUtil.getConnection();
        String sql = "delete from orderinfo where orderId = ?";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, orderId);
            result = pstm.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }
    //增加用户记录
    public int insertOrder(int orderId,String orderBeginDate,String orderEndDate,int waiterId,int orderState,int tableId) {
        Connection connection = DBUtil.getConnection();
        String sql = "insert into orderinfo(orderId,orderBeginDate,orderEndDate,waiterId,orderState,tableId) " + "values(?,?,?,?,?,?);";
        PreparedStatement pstm = null;
        int result = 0;

        try {
            pstm = connection.prepareStatement(sql);
            pstm.setInt(1, orderId);
            pstm.setString(2, orderBeginDate);
            pstm.setString(3, orderEndDate);
            pstm.setInt(4, waiterId);
            pstm.setInt(5, orderState);
            pstm.setInt(6, tableId);


            result = pstm.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            DBUtil.close(pstm, null, connection);
        }
        return result;
    }



}
