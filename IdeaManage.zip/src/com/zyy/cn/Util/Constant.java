package com.zyy.cn.Util;

public class Constant {
    public final  static String USER_SESSION ="USER_SESSION";
}
