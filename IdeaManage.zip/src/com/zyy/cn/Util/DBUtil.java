package com.zyy.cn.Util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 数据库连接工具类
 * @author ERIC ZHAI
 * @date 2022/08/03
 */
public class DBUtil {

    private static String url;
    private static String username;
    private static String password;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("JDBC驱动加载完成");
            Properties properties = new Properties();
            //File file = new File("src\\db.properties");

//            InputStream in = DBUtil.class.getClassLoader().getResourceAsStream("/db.properties");
//
//            properties.load(in);
             url = "jdbc:mysql://localhost:3306/stu_manage?useUnicode=true&characterEncoding=utf-8&useSSL=false";
             username = "root";
             password = "123456";

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }  catch (Exception e) {
            e.printStackTrace();
        }
    }

    //获取数据库连接
    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    //关闭数据库连接
    public static void close(PreparedStatement pstm, ResultSet rs, Connection connection) {
        try {
            if (pstm != null) {
                pstm.close();
            }

            if (rs != null) {
                rs.close();
            }
            if (connection != null) {
                connection.close();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        Connection connection = DBUtil.getConnection();
        String sql = "select * from message";
        PreparedStatement pstm  = null;
        ResultSet rs = null;
        try {
            pstm = connection.prepareStatement(sql);
            rs = pstm.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("Message"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.close(pstm, rs, connection);
        }
    }
}

