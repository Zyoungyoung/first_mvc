package com.zyy.cn.main;
import com.zyy.cn.Util.DBUtil;
import java.sql.*;

public class UserJudege {

    public int judge(String name, String password) throws SQLException {
        int i = 0;
        Connection ct = null;
//        来进行数据库的简单链接
        Statement st = null;
        ResultSet rt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String username = "root";
            String passworwd = "123456";
            String url = "jdbc:mysql://localhost:3306/stu_manage?useUnicode=true&characterEncoding=utf-8&useSSL=false";
            ct = DriverManager.getConnection(url, username, passworwd);
            st = ct.createStatement();
            String sql = "select * from userinfo";
            rt = st.executeQuery(sql);
            while (rt.next()) {
                //System.out.println("name"+rt.getString("userAccount"));
//                用于输出当前数据库的名字以及密码
                if (name.equals(rt.getString("userAccount")) && password.equals(rt.getString("userPass"))) {
                    //获取当前数据库中role的值，转化为integer 用于判断他的身份
                    i = Integer.valueOf(rt.getString("role")).intValue();

                }
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (st != null) {
                st.close();
            }
            if (ct != null) {
                ct.close();
            }
        }

        return i;
    }

}
