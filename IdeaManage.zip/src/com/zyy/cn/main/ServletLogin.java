package com.zyy.cn.main;

import com.zyy.cn.Util.Constant;


import javax.servlet.Filter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/Login")
public class ServletLogin extends HttpServlet  {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //doGet(req, resp);
        //resp.setContentType("test/html;charset=utf-8");
//        创建一个session对象用于过滤器
        HttpSession session =req.getSession();

        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("username");
        //从表单中获取表单的名字和密码、验证码
        String password = req.getParameter("password");
        String Code = req.getParameter("vercode");
        session.setAttribute("username",name);



        UserJudege ju = new UserJudege();
//        UserJudege是一个判断方法，可以将表单数据传输到数据库系统进行对比，下面代码就是判断语句
        try {
            if (Code.equals(req.getSession().getAttribute("code"))){
//                判断验证码是否正确
              if(ju.judge(name,password)>0){
//                  当用户名成功登录后创建session
                  req.getSession().setAttribute("USER_SESSION", Constant.USER_SESSION);
                    //判断前台输入的验证码和后台生成的验证码是否正确
                switch (ju.judge(name,password)){
                    case 1:
//                        餐厅管理员页面
                        resp.sendRedirect("Manager.jsp?username="+name);
                        break;
                    case 2:
//                        后厨页面
                        resp.sendRedirect("main.jsp?username="+name);
                        break;
                    case 3:
//                        服务员管理界面
                        resp.sendRedirect("Waiter.jsp?username="+name);
                        break;
                }
                } else{
                  resp.sendRedirect("login.jsp?error=yes");
                }
            }else{
                //验证码输入错误的时候
                resp.sendRedirect("login.jsp?code=no");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }




    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
