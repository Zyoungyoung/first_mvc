package com.zyy.cn.Impl;

public interface UserServiceImp {
    //增删改查四个功能模块

}
