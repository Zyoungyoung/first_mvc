package com.zyy.cn.Impl;

public interface CookerServiceImp {
    public String sendDish();
    //发送菜品订单信息
    public String acceptMessage();
    //接受管理员公告信息
    public String amend();
    //修改厨师个人信息
    public int confirmDish();
    //确认菜品订单信息


}
