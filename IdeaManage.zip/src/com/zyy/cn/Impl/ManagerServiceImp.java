package com.zyy.cn.Impl;

public interface ManagerServiceImp {

}
