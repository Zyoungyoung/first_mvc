// app.get("/alluser", function(req, res) {
//     usersDB(`select * from user`, function(data) {
//         res.json({ "data": data });
//         console.log("返回的数据库数据2", data);
//     })
// })
